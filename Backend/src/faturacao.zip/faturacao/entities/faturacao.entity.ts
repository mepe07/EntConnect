export class Faturacao {}
