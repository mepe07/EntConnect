export class CreateFaturacaoDto {}
